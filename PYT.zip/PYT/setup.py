from setuptools import setup
setup(name = "Floyd_System",
      version = "beta",
      url = "https://github.com/mirage2139/FloydSystem.git",
      author = "Mirage",
      author_email = "litosov07@gmail.com",    
      install_requires = ["bs4","kivy","kivymd","requests","fake_useragent",
                      "schedule","time","threading","playsound",
                      "opencv-python", "Pillow", "glob", "cv2", "os", "geolocation-python"],
      zip_safe = False
      )
