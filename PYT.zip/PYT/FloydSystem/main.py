'''
Code plan:

Нейросеть для видеонаблюдения (сторонняя утилита) и видеонаблюдение
Сайт для просмотра камер
Поиск URL остановки по координатам
Поиск улицы по координатам
Проскси
Погода
TG Api Audio
Получение видео через реквесты
Обновление получения данных
Completed (fix timer) - Обновление интерфейса


Mirage
tg - @mirage2139
'''


#Импорт сторонних утилит

#Утилиты системы
import util #Адаптация названия файлов + Работа над анимациями
import get_location #Получение локации

#Графический фреймворк
import kivy
import kivymd
from kivymd.app import MDApp 
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.widget import Widget
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.core.audio import SoundLoader

import requests #Библиотека запросов
from fake_useragent import UserAgent #Библиотека ложных заголовков
from bs4 import BeautifulSoup #Библиотека чтения html файлов

import os #утилита системы

#Библиотеки для работы таймера
import schedule 
import time
import threading

#Глобальные переменные

get_location = False


#Проверка надобности получения координат остановки
if get_location == False:
    street = "Малая Морская улица, 7, Санкт-Петербург" #Улица, отображаемая на карте в интерфейсе
    parse_url = "https://yandex.ru/maps/2/saint-petersburg/stops/stop__10075076/?indoorLevel=1&ll=30.316053%2C59.935873&tab=overview&z=17.26" #URL остановки в Y.Maps
else:
    get_location.main()
    
# Генерируем случайный заголовок
ua = UserAgent()
randomheaders = ua.random
print("Fake headers: ", randomheaders)
headers = {'User-Agent': randomheaders}

#Основной код

# Работа с графикой
Window.fullscreen = 'auto'

# Функция для парсинга данных
def parse_bus(url):
    try:
        print("Parsing pub transport")
        req = requests.get(url, headers=headers)
        html_content = req.text

        with open("info\Content.html", "w", encoding="utf-8") as file:
            file.write(html_content)
            file.close()
    except Exception as e:
        print(e)
#Функция для получения информации из файла

def get_info():
    global tram_list, bus_list, minibus_list, trollbus_list, bus_time, first_bus, stop_name, buses, trollbuses, trams
    try:
        print("Trying to get info")
        with open("info\Content.html", "r", encoding="utf-8") as file:
            bs = BeautifulSoup(file, "lxml")
            stop_name = bs.find("h1", class_="card-title-view__title").text
            bus_list = bs.find_all("div", class_="masstransit-transport-list-view__type-transport _type_bus _highlighted")
            minibus_list = bs.find_all("div", class_="masstransit-transport-list-view__type-transport _type_minibus _highlighted")
            trollbus_list = bs.find_all("div", class_="masstransit-transport-list-view__type-transport _type_trolleybus _highlighted")
            tram_list = bs.find_all("div", class_="masstransit-transport-list-view__type-transport _type_tramway _highlighted")
            first_bus = bs.find("span", class_="masstransit-vehicle-snippet-view__main-text")
            bus_time = bs.find("span", class_="masstransit-prognoses-view__title-text")
            file.close()
        buses, trollbuses, trams = [],[],[]  #Списки ТС  
        for bus in bus_list:
            buses.append(bus.text + "\n")
        for bus in minibus_list:
            buses.append(bus.text + '\n')
        print(buses)
        for trollbus in trollbus_list:
            trollbuses.append(trollbus.text + '\n')
        print(trollbuses)
        for tram in tram_list:
            trams.append(tram.text + '\n')
        print(trams)
        #os.remove("info\Content.html")
    except Exception as e:
        print(e)



#Код GUI
class Bus_NUmber(MDBoxLayout):
    def update_labels(self, *args):
        global trollbuses,buses,trams,stop_name,first_bus
        print("Update in process")
        #parse_bus(parse_url)
        get_info()
        layout = self
        Label_Bus = layout.ids.list_label
        Label_Bus.text = "Список номеров машин общественного транспорта:\n"
        all_elements = len(buses+trollbuses+trams)
        if buses != []:
           Label_Bus.text += "Автобус №"+"Автобус №".join(buses) # отображение списка автобусов на экран
        if trollbuses != []:
           Label_Bus.text += "Троллейбус №"+"Троллейбус №".join(trollbuses) # отображение списка троллейбусов на экран
        if trams != []:
            Label_Bus.text += "Трамвай №"+"Трамвай №".join(trams) # отображение списка трамваев на экран
        Label_Bus.text += "\n"*(16-all_elements)
        label_street=layout.ids.street_name 
        label_street.text="Остановка общественного транспорта:\n" + stop_name# отображение названия остановки
        firstbus = layout.ids.first_bus 
        firstbus.text = f"Транспортное средство №{first_bus.text}   -   {bus_time.text}" # отображение ближайшего автобуса
        if bus_time.text == "прибывает":
            print("Sound func in process")
            bus = util.change_name(first_bus.text)
            gifka = f"graph\\{bus}.gif"
            if os.path.isfile(gifka):
                layout.ids.gif.source = gifka
            else:
                util.convert(bus,"temp_files\\{bus}.mp4")
                util.merge(f"temp_files\\{bus}.gif")
                layout.ids.gif.source = gifka
            try:
                sound = SoundLoader.load(f"audio\\{bus}.mp3")
                sound.play()
            except Exception as e:
                print(e)
        else:
            layout.ids.gif.source = f"graph\\nothing.gif"

# Функция для получения координат остановвки   
def get_coordinates(location):
    print("Getting coordinates in process")
    global latitude, longtitude
    api_key = "ade888aa-9834-43ee-88c9-2c55dc74c709"

    url_api = f"https://geocode-maps.yandex.ru/1.x/?apikey={api_key}&geocode={location}&format=json"
    
    try:
        response = requests.get(url_api, headers=headers).json()
        coordinates = response['response']['GeoObjectCollection']['featureMember'][0]['GeoObject']['Point']['pos']
        longitude, latitude = map(float, coordinates.split())
        return latitude, longitude
    except Exception as e:
        # Обработка ошибки при запросе к API или при извлечении координат
        print(f"Произошла ошибка: {e}")
    
# Функция для получения статического изображения карты
def get_map(location):
    print("Getting a map in process")
    global latitude, longitude
    # Получение координат остановки
    latitude, longitude = get_coordinates(location)
    try:
        # Создание запроса к Yandex Static API для получения статического изображения карты
        url = f"https://static-maps.yandex.ru/1.x/?ll={longitude},{latitude}&size=650,400&z=14&l=map&pt={longitude},{latitude},pm2rdm"
        response = requests.get(url,headers=headers)
    except Exception as e:
        print(e)
    
    # Сохранение изображения карты
    with open("graph\map.png", "wb") as f:
        f.write(response.content)
    return url, latitude, longitude


# В методе build() класса MyApp добавляем вызов Clock.schedule_interval() для обновления данных:    
#  Основной класс программы
class MyApp(MDApp):
    def build(self):
        layout = Bus_NUmber()
        Clock.schedule_interval(layout.update_labels, 8)
        return layout
if __name__=="__main__":
    #get_map(street)
    parse_bus(parse_url)
    get_info()
    MyApp().run()
