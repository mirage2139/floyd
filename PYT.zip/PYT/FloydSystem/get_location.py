import socket
import sqlite3
def main():
    ip = socket.gethostname()
    try:
        new_data = location(ip)
    except ValueError:
        pass

def location(ip):
    response = requests.get(f"http://ip-api.com/json/{ip}?lang=ru")
    if response.status_code == 404:
        print("Error")
    result = response.json()
    if result["status"] == "fail":
        return main("Invalid ip")

    record = []

    for key, value in result.items():
        record.append(value)
        print(f"[{key.title()}]: {value}")
    return tuple(record)
