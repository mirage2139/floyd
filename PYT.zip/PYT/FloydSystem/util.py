import cv2
import glob
from PIL import Image
import aspose.words as aw


def convert(word,path):
    video_capture = cv2.VideoCapture(path)
    still_reading, image = video_capture.read()
    frame_count = 0
    while still_reading:
        cv2.imwrite(f"temp_files\frame_{frame_count:03d}.jpg", image)
        
        # read next image
        still_reading, image = video_capture.read()
        frame_count += 1
    images = glob.glob("temp_files\*.jpg")
    images.sort()
    frames = [Image.open(image) for image in images]
    frame_one = frames[0]
    frame_one.save(f"temp_files\{word}.gif", format="GIF", append_images=frames,
                   save_all=True, duration=50, loop=0)

def merge(gif):
    fileNames = [ "temp_files\gifs\trans.gif", f"temp_files\gifs\{gif}.gif","temp_files\gifs\nearyou.gif" ]

    doc = aw.Document()
    builder = aw.DocumentBuilder(doc)

    shapes = [builder.insert_image(fileName) for fileName in fileNames]
    pageSetup = builder.page_setup
    pageSetup.page_width = max(shape.width for shape in shapes)
    pageSetup.page_height = sum(shape.height for shape in shapes)
    pageSetup.top_margin = 0
    pageSetup.left_margin = 0
    pageSetup.bottom_margin = 0
    pageSetup.right_margin = 0

    doc.save(f"graph\{gif}.gif")

def change_name(word):
    fullword = ""
    for let in word:
        if (let == "0"):
            fullword += 'z'
        elif (let == "1"):
            fullword += 'o'
        elif (let == "2"):
            fullword += 'tw'
        elif (let == "3"):
            fullword += 'th'
        elif (let == "4"):
            fullword += 'fo'
        elif (let == "5"):
            fullword += 'fi'
        elif (let == "6"):
            fullword += 'si'
        elif (let == "7"):
            fullword += 'se'
        elif (let == "8"):
            fullword += 'e'
        elif (let == "9"):
            fullword += 'n'
    return fullword

